function Global.SetGameplayCamRelativePitch(x, Value2)
	return _in(0xFB760AF4F537B8BF, x, Value2)
end
