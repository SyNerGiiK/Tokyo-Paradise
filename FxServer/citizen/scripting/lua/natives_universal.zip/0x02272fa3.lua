function Global.SetMpGamerTagColor(player, username, pointedClanTag, isRockstarClan, clanTag, clanFlag, r, g, b)
	return _in(0x6DD05E9D83EFA4C9, player, _ts(username), pointedClanTag, isRockstarClan, _ts(clanTag), clanFlag, r, g, b)
end
