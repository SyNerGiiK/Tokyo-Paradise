function Global.IsPauseMenuActive()
	return _in(0x535384D6067BA42E, _r)
end
