function Global.N_0xe2c3cec3c0903a00(p0)
	return _in(0xE2C3CEC3C0903A00, p0, _r, _ri)
end
