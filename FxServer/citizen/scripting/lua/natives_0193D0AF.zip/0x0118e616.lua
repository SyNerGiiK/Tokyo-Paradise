function Global.AddTrevorRandomModifier(gamerTagId)
	return _in(0x595B5178E412E199, gamerTagId, _r)
end
