function Global.DoorSystemGetDoorPendingState(doorHash)
	return _in(0x4BC2854478F3A749, _ch(doorHash), _r, _ri)
end
