function Global.RequestScript(scriptName)
	return _in(0x6EB5F71AA68F2E8E, _ts(scriptName))
end
