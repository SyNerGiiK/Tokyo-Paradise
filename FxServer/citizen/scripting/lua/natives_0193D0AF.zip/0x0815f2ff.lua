function Global.SetVehicleEngineCanDegrade(vehicle, toggle)
	return _in(0x983765856F2564F9, vehicle, toggle)
end
