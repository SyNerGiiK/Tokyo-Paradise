--- NativeDB Introduced: v1180
-- @param p0 :
function Global.N_0x75627043c6aa90ad(p0)
	return _in(0x75627043C6AA90AD, p0)
end
