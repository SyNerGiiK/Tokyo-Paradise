function Global.N_0xa80ff73f772acf6a(p0, p1)
	return _in(0xA80FF73F772ACF6A, p0, p1)
end
