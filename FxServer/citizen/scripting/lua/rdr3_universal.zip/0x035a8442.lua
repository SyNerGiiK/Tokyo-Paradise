function Global.N_0xbd94cecfb2d65119(p0, p1, p2, p3, p4, p5)
	return _in(0xBD94CECFB2D65119, p0, p1, p2, p3, p4, p5)
end
