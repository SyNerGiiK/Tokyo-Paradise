function Global.DominoesBuyIn(p0)
	return _in(0x399E6CD12FC8CA89, p0, _r, _ri)
end
