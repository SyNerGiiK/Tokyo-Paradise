function Global.IsNewLoadSceneLoaded()
	return _in(0x01B8247A7A8B9AD1, _r)
end
