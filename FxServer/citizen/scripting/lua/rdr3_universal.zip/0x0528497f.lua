function Global.N_0x8800776e410eb669(p0)
	return _in(0x8800776E410EB669, p0, _r, _ri)
end
