function Global.N_0xa2116c1e4ed85c24(p0, p1)
	return _in(0xA2116C1E4ED85C24, p0, p1)
end
