function Global.N_0x32ccad8a981b53d3(p0)
	return _in(0x32CCAD8A981B53D3, p0)
end
