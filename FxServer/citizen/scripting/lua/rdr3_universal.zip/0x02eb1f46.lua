function Global.N_0xd55db4466d00a258(p0)
	return _in(0xD55DB4466D00A258, p0, _r, _ri)
end
