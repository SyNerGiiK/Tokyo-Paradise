function Global.SetPedStealthMovement(p0, p1, p2, p3)
	return _in(0x88CBB5CEB96B7BD2, p0, p1, p2, p3)
end
