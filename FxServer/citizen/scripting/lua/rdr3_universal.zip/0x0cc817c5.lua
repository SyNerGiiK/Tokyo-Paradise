function Global.N_0x36d0f2ba2c0d9bde(p0, p1)
	return _in(0x36D0F2BA2C0D9BDE, p0, p1, _r, _ri)
end
