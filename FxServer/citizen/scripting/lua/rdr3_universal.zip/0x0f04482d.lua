function Global.N_0x8af46e5159a5b620(p0, p1)
	return _in(0x8AF46E5159A5B620, p0, p1)
end
