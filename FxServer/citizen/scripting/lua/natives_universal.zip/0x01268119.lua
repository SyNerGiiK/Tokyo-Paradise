--- FORCE_*
function Global.N_0x9b079e5221d984d3(p0)
	return _in(0x9B079E5221D984D3, p0)
end
