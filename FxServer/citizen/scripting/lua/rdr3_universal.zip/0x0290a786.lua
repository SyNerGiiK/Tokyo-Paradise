function Global.N_0x8ae4efa464dae42d(p0, p1)
	return _in(0x8AE4EFA464DAE42D, p0, p1)
end
