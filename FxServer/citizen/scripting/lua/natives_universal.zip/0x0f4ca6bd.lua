--- NativeDB Parameter 1: float p1
function Global.N_0xcf1182f682f65307(cargobob, p1)
	return _in(0xCF1182F682F65307, cargobob, p1)
end
