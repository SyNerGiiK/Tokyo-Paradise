function Global.N_0x018f30d762e62df8(p0, p1)
	return _in(0x018F30D762E62DF8, p0, p1, _r, _ri)
end
