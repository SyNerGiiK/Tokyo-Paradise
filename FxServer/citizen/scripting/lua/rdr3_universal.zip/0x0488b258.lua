function Global.N_0x34c9af25649172d0(p0)
	return _in(0x34C9AF25649172D0, p0)
end
