function Global.TaskRappelFromHeli(ped, unused)
	return _in(0x09693B0312F91649, ped, unused)
end
