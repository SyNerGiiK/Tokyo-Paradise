function Global.N_0x2b32b11520626229(p0, p1, p2, p3, p4)
	return _in(0x2B32B11520626229, p0, p1, p2, p3, p4, _r, _ri)
end
