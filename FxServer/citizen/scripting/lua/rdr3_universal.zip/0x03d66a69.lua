function Global.N_0x1919d59e60fd516e(p0, p1, p2)
	return _in(0x1919D59E60FD516E, p0, p1, p2)
end
