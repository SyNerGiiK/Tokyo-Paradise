function Global.N_0xc93a9a45430d484e(p0)
	return _in(0xC93A9A45430D484E, p0, _r, _ri)
end
