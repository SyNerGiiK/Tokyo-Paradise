function Global.N_0x05dd384f39de1c8c(p0, p1)
	return _in(0x05DD384F39DE1C8C, p0, p1, _r, _ri)
end
