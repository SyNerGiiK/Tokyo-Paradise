function Global.ClearGpsPlayerWaypoint()
	return _in(0x08FDC6F796E350D1)
end
