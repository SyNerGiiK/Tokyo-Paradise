function Global.CreateModelSwap(x, y, z, radius, originalModel, newModel, p6)
	return _in(0x10B2218320B6F5AC, x, y, z, radius, _ch(originalModel), _ch(newModel), p6)
end
