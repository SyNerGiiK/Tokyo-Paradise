function Global.SetVehicleProvidesCover(vehicle, toggle)
	return _in(0x652712478F1721F4, vehicle, toggle)
end
