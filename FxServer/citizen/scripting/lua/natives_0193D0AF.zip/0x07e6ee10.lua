function Global.ClearAreaOfEverything(x, y, z, radius, p4, p5, p6, p7)
	return _in(0x957838AAF91BD12D, x, y, z, radius, p4, p5, p6, p7)
end
