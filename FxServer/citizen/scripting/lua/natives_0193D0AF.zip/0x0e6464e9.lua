function Global.N_0xd2b315b6689d537d(player, p1)
	return _in(0xD2B315B6689D537D, player, p1)
end
