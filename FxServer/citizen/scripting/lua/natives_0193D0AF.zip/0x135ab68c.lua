function Global.TaskGetOffBoat(ped, boat)
	return _in(0x9C00E77AF14B2DFF, ped, boat)
end
