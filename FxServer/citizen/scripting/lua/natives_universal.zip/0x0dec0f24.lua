--- NativeDB Introduced: v1290
-- @param vehicle :
-- @param toggle :
function Global.SetVehicleHoverTransformActive(vehicle, toggle)
	return _in(0x2D55FE374D5FDB91, vehicle, toggle)
end
