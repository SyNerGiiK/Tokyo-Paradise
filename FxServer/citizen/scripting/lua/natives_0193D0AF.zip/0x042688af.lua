function Global.AnyPassengersRappeling(vehicle)
	return _in(0x291E373D483E7EE7, vehicle, _r)
end
