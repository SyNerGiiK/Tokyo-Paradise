function Global.N_0xba958f68031ddbfc(p0, p1)
	return _in(0xBA958F68031DDBFC, p0, p1, _r, _rv)
end
