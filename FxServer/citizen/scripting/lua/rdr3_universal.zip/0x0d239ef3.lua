function Global.GetRandomFloatInRange(startRange, endRange)
	return _in(0xE29F927A961F8AAA, startRange, endRange, _r, _rf)
end
