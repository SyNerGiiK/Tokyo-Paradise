function Global.RaiseRetractableWheels(vehicle)
	return _in(0xF660602546D27BA8, vehicle)
end
