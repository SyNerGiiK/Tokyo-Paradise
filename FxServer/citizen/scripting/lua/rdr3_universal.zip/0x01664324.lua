function Global.IsVehicleNodeIdValid(vehicleNodeId)
	return _in(0x5829A02AF4F0B3CB, vehicleNodeId, _r)
end
