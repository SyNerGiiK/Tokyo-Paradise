--- Nulls out the elements stored in CGameStreamMgr + 673, a value inherited from CGameStreamMgr + 15417 (1604)
function Global.ThefeedClearFrozenPost()
	return _in(0x80FE4F3AB4E1B62A)
end
