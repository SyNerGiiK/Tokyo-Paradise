function Global.N_0x61e111e323419e07(index, spStat, charStat, character)
	return _in(0x61E111E323419E07, index, spStat, charStat, character, _r, _ri)
end
