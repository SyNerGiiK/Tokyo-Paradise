function Global.N_0xc17ad0e5752becda(componentHash)
	return _in(0xC17AD0E5752BECDA, _ch(componentHash), _r, _ri)
end
