function Global.N_0xfc7f71cf49f70b6b(p0)
	return _in(0xFC7F71CF49F70B6B, p0)
end
