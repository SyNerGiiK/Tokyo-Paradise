function Global.N_0xe956c2340a76272e(p0)
	return _in(0xE956C2340A76272E, p0, _r, _ri)
end
