function Global.Atan2(p0, p1)
	return _in(0x8927CBF9D22261A4, p0, p1, _r, _rf)
end
