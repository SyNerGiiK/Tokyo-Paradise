function Global.N_0x1461b28a06717d68(p0)
	return _in(0x1461B28A06717D68, p0, _r, _ri)
end
