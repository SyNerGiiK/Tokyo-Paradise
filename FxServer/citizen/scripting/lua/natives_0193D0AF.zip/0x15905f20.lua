function Global.NetworkShopBeginService(p1, p2, p3, p4, p5)
	return _in(0x3C5FD37B5499582E, _i, p1, p2, p3, p4, p5, _r)
end
