--- See [`GetTimecycleModifierIndex`](#_0xFDF3D97C674AFB66) for use, works the same just for the secondary timecycle modifier.
-- @return An integer representing the Timecycle modifier
function Global.N_0xbb0527ec6341496d()
	return _in(0xBB0527EC6341496D, _r, _ri)
end
