function Global.UpdateLightsOnEntity(entity)
	return _in(0xDEADC0DEDEADC0DE, entity)
end
