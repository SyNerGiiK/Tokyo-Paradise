function Global.N_0x09e378c52b1433b5(p0, p1, p2, p3, p4)
	return _in(0x09E378C52B1433B5, p0, p1, p2, p3, p4)
end
