function Global.GetInteriorPortalFlag(interiorId, portalIndex)
	return _in(0xc74da47c, interiorId, portalIndex, _r, _ri)
end
