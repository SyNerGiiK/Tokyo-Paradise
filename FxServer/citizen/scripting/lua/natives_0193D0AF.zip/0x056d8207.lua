function Global.N_0x758a5c1b3b1e1990(p0)
	return _in(0x758A5C1B3B1E1990, p0)
end
