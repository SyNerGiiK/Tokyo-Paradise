function Global.SetEveryoneIgnorePlayer(player, toggle)
	return _in(0x34630A768925B852, player, toggle)
end
