function Global.N_0x4a8fefc43fd8ac9b(p0, p1, p2)
	return _in(0x4A8FEFC43FD8AC9B, p0, p1, p2)
end
