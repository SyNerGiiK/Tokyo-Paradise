function Global.N_0x140b3cb1d424a945(p0, p1)
	return _in(0x140B3CB1D424A945, p0, p1)
end
