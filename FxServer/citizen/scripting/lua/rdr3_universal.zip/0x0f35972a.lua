function Global.N_0xc0940ac858c1e126(p0)
	return _in(0xC0940AC858C1E126, p0, _r, _ri)
end
