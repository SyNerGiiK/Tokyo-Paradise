function Global.N_0xa0ae7653e8181725(p0)
	return _in(0xA0AE7653E8181725, p0, _r, _ri)
end
