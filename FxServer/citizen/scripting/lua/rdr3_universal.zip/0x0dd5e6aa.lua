function Global.N_0xd97d8d905f1562f2(p0)
	return _in(0xD97D8D905F1562F2, p0, _r, _ri)
end
