function Global.N_0x7d654266025e921b(p0)
	return _in(0x7D654266025E921B, p0)
end
