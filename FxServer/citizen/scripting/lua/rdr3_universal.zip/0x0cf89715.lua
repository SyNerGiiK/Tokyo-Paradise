function Global.N_0xf47e33f8d2523825(p0, p1)
	return _in(0xF47E33F8D2523825, p0, p1, _r, _ri)
end
