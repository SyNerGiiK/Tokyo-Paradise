function Global.ApplyPedBloodByZone(ped, p1, p2, p3, p4)
	return _in(0x3311E47B91EDCBBC, ped, p1, p2, p3, _ii(p4) --[[ may be optional ]])
end
