--- NETWORK_START_R/S*
function Global.NetworkStartSoloTutorialSession()
	return _in(0x17E0198B3882C2CB)
end
