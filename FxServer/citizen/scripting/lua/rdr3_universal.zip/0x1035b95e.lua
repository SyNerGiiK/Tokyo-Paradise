function Global.N_0x506ce71fb6e8cf5e(p0, p1)
	return _in(0x506CE71FB6E8CF5E, p0, p1)
end
