function Global.N_0x73118a3ee9c9b6db(p0, p1, p2)
	return _in(0x73118A3EE9C9B6DB, p0, p1, p2)
end
