function Global.NetworkIsFriendOnline_2(networkHandle)
	return _in(0x87EB7A3FFCB314DB, _ii(networkHandle) --[[ may be optional ]], _r)
end
