function Global.N_0xd8c3be3ee94caf2d(x, y, z, p3, p4)
	return _in(0xD8C3BE3EE94CAF2D, x, y, z, p3, p4)
end
