--- NativeDB Introduced: v1290
-- @param p0 :
-- @param p1 :
function Global.N_0x8821196d91fa2de5(p0, p1)
	return _in(0x8821196D91FA2DE5, p0, p1)
end
