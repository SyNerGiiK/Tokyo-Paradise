--- Enable / disable showing route for the Blip-object.
function Global.SetBlipRoute(blip, enabled)
	return _in(0x4F7D8A9BFB0B43E9, blip, enabled)
end
