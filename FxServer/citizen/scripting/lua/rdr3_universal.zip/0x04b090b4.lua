function Global.N_0xce71c2f9baa3f975(p0, p1)
	return _in(0xCE71C2F9BAA3F975, p0, p1)
end
