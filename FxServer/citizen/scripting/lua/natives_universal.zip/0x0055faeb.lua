--- NETWORK_GET_*
-- NativeDB Introduced: v323
-- @param player :
function Global.NetworkGetOldestResendCountForPlayer(player)
	return _in(0x52C1EADAF7B10302, player, _r, _ri)
end
