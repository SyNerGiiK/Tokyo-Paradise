function Global.N_0x20c6c7e4eb082a7f(p0)
	return _in(0x20C6C7E4EB082A7F, p0)
end
