function Global.N_0x0ff2862b61a58af9(p0)
	return _in(0x0FF2862B61A58AF9, p0)
end
