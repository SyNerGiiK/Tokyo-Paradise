function Global.N_0x580d71dfe0088e34(p0, p1)
	return _in(0x580D71DFE0088E34, p0, p1, _r, _ri)
end
