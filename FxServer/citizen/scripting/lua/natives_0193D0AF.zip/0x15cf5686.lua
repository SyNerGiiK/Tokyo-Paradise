function Global.GetOffsetFromInteriorInWorldCoords(interiorID, x, y, z)
	return _in(0x9E3B3E6D66F6E22F, interiorID, x, y, z, _r, _rv)
end
