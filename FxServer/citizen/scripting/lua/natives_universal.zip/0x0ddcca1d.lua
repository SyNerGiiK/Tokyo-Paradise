--- Defines the state of a destructible object.
-- Use the GET_RAYFIRE_MAP_OBJECT native to find an object's handle with its name / coords
-- State 2 == object just spawned
-- State 4 == Beginning of the animation
-- State 6 == Start animation
-- State 9 == End of the animation
function Global.SetStateOfRayfireMapObject(object, state)
	return _in(0x5C29F698D404C5E1, object, state)
end
