function Global.PromptSetMashManualModePressedGrowthSpeed(prompt, p1)
	return _in(0x56DBB26F98582C29, prompt, p1)
end
