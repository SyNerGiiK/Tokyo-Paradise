function Global.N_0xafa14f98327791ce(p0)
	return _in(0xAFA14F98327791CE, p0, _r, _ri)
end
