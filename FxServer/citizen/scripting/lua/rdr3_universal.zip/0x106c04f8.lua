function Global.N_0x354f689c4ffaab37(p0)
	return _in(0x354F689C4FFAAB37, p0, _r, _ri)
end
