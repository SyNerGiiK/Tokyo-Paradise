function Global.N_0x1e8099f449abb0ba(p0)
	return _in(0x1E8099F449ABB0BA, p0, _r, _ri)
end
