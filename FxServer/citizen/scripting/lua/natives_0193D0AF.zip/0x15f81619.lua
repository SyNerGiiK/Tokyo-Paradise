function Global.NetworkSessionHostClosed(p0, maxPlayers)
	return _in(0xED34C0C02C098BB7, p0, maxPlayers, _r)
end
