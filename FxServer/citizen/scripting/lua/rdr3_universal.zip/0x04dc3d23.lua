function Global.N_0x789dabd18e9024db(p0, p1, p2)
	return _in(0x789DABD18E9024DB, p0, p1, p2)
end
