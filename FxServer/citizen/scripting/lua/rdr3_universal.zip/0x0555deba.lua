function Global.IsEntityAttachedToAnyVehicle(entity)
	return _in(0x12DF6E0D2E736749, entity, _r)
end
