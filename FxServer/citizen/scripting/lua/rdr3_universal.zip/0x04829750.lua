function Global.N_0xb93a769b8b726950(p0, p1)
	return _in(0xB93A769B8B726950, p0, p1)
end
