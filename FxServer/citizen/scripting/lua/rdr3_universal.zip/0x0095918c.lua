function Global.N_0x6bfbdc46139c45ab(p0, p1, p2)
	return _in(0x6BFBDC46139C45AB, p0, p1, p2, _r, _ri)
end
