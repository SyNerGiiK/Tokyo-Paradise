function Global.HasEntityBeenDamagedByAnyVehicle(entity)
	return _in(0xDFD5033FDBA0A9C8, entity, _r)
end
