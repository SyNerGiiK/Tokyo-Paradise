function Global.N_0xe4e2c581f127a11c(p0, p1)
	return _in(0xE4E2C581F127A11C, p0, p1)
end
