function Global.N_0x923346025512dfb7(p0)
	return _in(0x923346025512DFB7, p0, _r, _ri)
end
