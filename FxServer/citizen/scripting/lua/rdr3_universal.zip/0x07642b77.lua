function Global.N_0xf336e9f989b3518f(p0)
	return _in(0xF336E9F989B3518F, p0, _r, _ri)
end
