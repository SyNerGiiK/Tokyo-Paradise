function Global.N_0x196d3acbeba4a44b(p0)
	return _in(0x196D3ACBEBA4A44B, p0)
end
