--- Sets bit 3 in GtaThread+0x150
-- SET_T*
function Global.N_0x6f2135b6129620c1(toggle)
	return _in(0x6F2135B6129620C1, toggle)
end
