function Global.N_0xfca8fb9e15fa80d3(p0, p1)
	return _in(0xFCA8FB9E15FA80D3, p0, p1)
end
