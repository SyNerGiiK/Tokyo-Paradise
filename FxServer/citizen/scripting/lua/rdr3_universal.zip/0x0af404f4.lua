function Global.N_0x1694a053dfb61a34(p0)
	return _in(0x1694A053DFB61A34, _ts(p0))
end
