--- NativeDB Introduced: v1365
-- @param p0 :
function Global.N_0x887fa38787de8c72(p0)
	return _in(0x887FA38787DE8C72, p0)
end
