function Global.SetCinematicButtonActive(p0)
	return _in(0xB90411F480457A6C, p0)
end
