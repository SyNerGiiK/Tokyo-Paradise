function Global.DoesTextBlockExist(gxt)
	return _in(0x1C7302E725259789, _ts(gxt), _r)
end
