function Global.SetAmbientVoiceName(ped, name)
	return _in(0x6C8065A3B780185B, ped, _ts(name))
end
