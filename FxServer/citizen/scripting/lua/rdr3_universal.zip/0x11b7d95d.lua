function Global.SetObjectTextureVariation(object, textureVariation)
	return _in(0x971DA0055324D033, object, textureVariation)
end
