function Global.SetAnimSceneInt(animScene, p1, p2, p3)
	return _in(0x3A379D2166CF5B92, animScene, p1, p2, p3)
end
