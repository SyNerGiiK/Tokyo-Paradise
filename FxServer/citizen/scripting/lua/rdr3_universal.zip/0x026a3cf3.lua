function Global.GetWaterHeight(x, y, z, height)
	return _in(0xFCA8B23F28813F69, x, y, z, _fi(height) --[[ may be optional ]], _r)
end
