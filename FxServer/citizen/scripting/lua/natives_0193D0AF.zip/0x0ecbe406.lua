function Global.NetworkSessionGetInviter(networkHandle)
	return _in(0xE57397B4A3429DD0, _ii(networkHandle) --[[ may be optional ]])
end
