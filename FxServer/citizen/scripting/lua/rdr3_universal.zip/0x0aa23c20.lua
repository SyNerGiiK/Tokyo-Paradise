function Global.UpdateLightsOnEntity(entity)
	return _in(0xBDBACB52A03CC760, entity)
end
