function Global.IsPedInjured(ped)
	return _in(0x84A2DD9AC37C35C1, ped, _r)
end
