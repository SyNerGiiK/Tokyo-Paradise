function Global.N_0x9d1eca9337be9fc3(p0, p1)
	return _in(0x9D1ECA9337BE9FC3, p0, p1, _r, _ri)
end
