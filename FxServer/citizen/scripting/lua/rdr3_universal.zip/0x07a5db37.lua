function Global.N_0x3b005ff0538ed2a9(p0)
	return _in(0x3B005FF0538ED2A9, p0, _r, _ri)
end
