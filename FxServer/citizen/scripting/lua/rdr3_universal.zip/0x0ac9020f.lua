function Global.TaskPickupCarriableEntity(p0, p1)
	return _in(0x502EC17B1BED4BFA, p0, p1)
end
