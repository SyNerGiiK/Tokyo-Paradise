function Global.N_0x2bae4880dcdd560b(p0, p1)
	return _in(0x2BAE4880DCDD560B, p0, p1, _r, _ri)
end
