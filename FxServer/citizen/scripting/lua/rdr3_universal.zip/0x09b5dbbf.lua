function Global.ScriptThreadIteratorReset()
	return _in(0x39382EB8DCD8684D)
end
