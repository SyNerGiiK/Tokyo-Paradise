function Global.N_0xa7479fb665361edb(p0, p1)
	return _in(0xA7479FB665361EDB, p0, p1)
end
