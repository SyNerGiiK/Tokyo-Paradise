function Global.GetEntityPopulationType(entity)
	return _in(0xADE28862B6D7B85B, entity, _r, _ri)
end
