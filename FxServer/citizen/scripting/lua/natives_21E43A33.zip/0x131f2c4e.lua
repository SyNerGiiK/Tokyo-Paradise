function Global.SetForcePedFootstepsTracks(enabled)
	return _in(0xAEEDAD1420C65CC0, enabled)
end
