function Global.N_0xc239dbd9a57d2a71(p0, p1, p2, p3, p4, p5, p6, p7)
	return _in(0xC239DBD9A57D2A71, p0, p1, p2, p3, p4, p5, p6, p7, _r, _ri)
end
