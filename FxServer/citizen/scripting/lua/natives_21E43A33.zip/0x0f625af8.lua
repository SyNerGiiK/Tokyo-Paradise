function Global.SetVehicleEnginePowerMultiplier(vehicle, value)
	return _in(0x93A3996368C94158, vehicle, value)
end
