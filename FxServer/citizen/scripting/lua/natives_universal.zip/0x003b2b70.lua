--- NativeDB Introduced: v1604
function Global.N_0x7148e0f43d11f0d9()
	return _in(0x7148E0F43D11F0D9)
end
