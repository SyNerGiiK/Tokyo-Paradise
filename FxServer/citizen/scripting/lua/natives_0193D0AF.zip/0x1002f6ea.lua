function Global.N_0xbe197eaa669238f4(p0, p1, p2, p3)
	return _in(0xBE197EAA669238F4, p0, p1, p2, p3, _r, _ri)
end
