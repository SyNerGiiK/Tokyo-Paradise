function Global.N_0x17fca7199a530203()
	return _in(0x17FCA7199A530203, _r, _ri)
end
