function Global.SetCloudHatOpacity(opacity)
	return _in(0xF36199225D6D8C86, opacity)
end
