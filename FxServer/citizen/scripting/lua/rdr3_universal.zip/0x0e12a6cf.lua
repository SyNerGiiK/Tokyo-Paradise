function Global.EnableScriptBrainSet(brainSet)
	return _in(0x1CF6E5C6750EADBD, brainSet)
end
