function Global.ForceRoomForEntity(entity, interior, roomHashKey)
	return _in(0xBC29A9894C976945, entity, interior, _ch(roomHashKey))
end
