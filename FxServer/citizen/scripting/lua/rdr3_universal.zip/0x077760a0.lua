function Global.N_0x4791899615d70fa2(p0, p1, p2)
	return _in(0x4791899615D70FA2, p0, p1, p2)
end
