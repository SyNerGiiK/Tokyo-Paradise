function Global.N_0x6b34be961f639e21(p0, p1)
	return _in(0x6B34BE961F639E21, p0, p1)
end
