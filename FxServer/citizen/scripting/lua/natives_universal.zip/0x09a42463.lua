--- Will cancel the transaction
function Global.NetGameserverEndService(transactionId)
	return _in(0xE2A99A9B524BEFFF, transactionId, _r)
end
