function Global.N_0x411189e51b8020ba(p0, p1)
	return _in(0x411189E51B8020BA, p0, p1)
end
