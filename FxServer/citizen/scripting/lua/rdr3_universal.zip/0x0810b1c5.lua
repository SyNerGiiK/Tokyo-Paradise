function Global.N_0x9ed3108d6847760a(p0, p1)
	return _in(0x9ED3108D6847760A, p0, p1)
end
