function Global.N_0x1d97da8acb5d2582(p0, p1)
	return _in(0x1D97DA8ACB5D2582, p0, p1)
end
