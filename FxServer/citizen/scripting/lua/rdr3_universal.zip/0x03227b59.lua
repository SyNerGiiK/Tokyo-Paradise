function Global.N_0x6ef4e31b4d5d2da0(p0, p1)
	return _in(0x6EF4E31B4D5D2DA0, p0, p1, _r, _ri)
end
