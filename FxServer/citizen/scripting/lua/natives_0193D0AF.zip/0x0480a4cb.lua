function Global.IsControlPressed(inputGroup, control)
	return _in(0xF3A21BCD95725A4A, inputGroup, control, _r)
end
