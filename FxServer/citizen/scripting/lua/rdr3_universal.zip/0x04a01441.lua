function Global.N_0x40ab73092c95b5f5(p0, p1, p2, p3)
	return _in(0x40AB73092C95B5F5, p0, p1, p2, p3)
end
