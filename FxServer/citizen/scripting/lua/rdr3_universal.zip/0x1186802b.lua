function Global.N_0x1a5c5d350068a673(p0, p1)
	return _in(0x1A5C5D350068A673, p0, p1)
end
