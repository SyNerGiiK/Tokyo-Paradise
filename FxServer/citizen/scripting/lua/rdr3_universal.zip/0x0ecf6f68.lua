function Global.N_0x5c674eb487891f6b()
	return _in(0x5C674EB487891F6B, _r, _ri)
end
