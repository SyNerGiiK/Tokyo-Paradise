function Global.N_0x86fafc18e3d4380c(p0, p1)
	return _in(0x86FAFC18E3D4380C, p0, p1)
end
