function Global.N_0x02c40bf885c567b6(p0)
	return _in(0x02C40BF885C567B6, p0, _r, _ri)
end
