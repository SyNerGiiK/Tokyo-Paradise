function Global.N_0xb292203008ebbaac(p0)
	return _in(0xB292203008EBBAAC, p0, _r, _ri)
end
