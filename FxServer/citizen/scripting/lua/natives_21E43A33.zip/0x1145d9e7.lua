function Global.ScInboxMessageGetDataInt(p0)
	return _in(0xA00EFE4082C4056E, p0, _i, _i, _r)
end
