function Global.N_0x05ac9e1e02975afb(p0, p1, p2)
	return _in(0x05AC9E1E02975AFB, p0, p1, p2)
end
