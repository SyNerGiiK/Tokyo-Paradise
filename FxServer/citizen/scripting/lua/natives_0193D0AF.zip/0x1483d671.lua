function Global.NetworkGetPlayerFromGamerHandle(networkHandle)
	return _in(0xCE5F689CF5A0A49D, _ii(networkHandle) --[[ may be optional ]], _r, _ri)
end
