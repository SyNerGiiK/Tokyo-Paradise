function Global.ChalNetStartGoal(p0, p1)
	return _in(0xC3FCB47344DCB638, p0, p1)
end
