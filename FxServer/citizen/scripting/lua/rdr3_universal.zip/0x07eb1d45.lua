function Global.N_0x78c2e029db205a3a(p0, p1)
	return _in(0x78C2E029DB205A3A, p0, p1)
end
