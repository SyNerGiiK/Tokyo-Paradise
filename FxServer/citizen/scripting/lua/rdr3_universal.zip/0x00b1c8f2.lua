function Global.N_0xf97c34c33487d569(p0, p1)
	return _in(0xF97C34C33487D569, p0, p1, _r, _ri)
end
