function Global.N_0x72068021f498e6e3(p0, p1, p2, p3)
	return _in(0x72068021F498E6E3, p0, p1, p2, p3, _r, _ri)
end
