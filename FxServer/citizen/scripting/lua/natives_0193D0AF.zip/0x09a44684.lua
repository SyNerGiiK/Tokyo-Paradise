function Global.ShowNumberOnBlip(blip, number)
	return _in(0xA3C0B359DCB848B6, blip, number)
end
