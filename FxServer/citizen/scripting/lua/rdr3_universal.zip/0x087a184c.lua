function Global.N_0xadc45010bc17af0e(p0, p1)
	return _in(0xADC45010BC17AF0E, p0, p1)
end
