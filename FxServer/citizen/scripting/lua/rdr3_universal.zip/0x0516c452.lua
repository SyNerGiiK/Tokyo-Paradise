function Global.N_0x73348402566ecb6e(p0, p1, p2, p3)
	return _in(0x73348402566ECB6E, p0, p1, p2, p3)
end
