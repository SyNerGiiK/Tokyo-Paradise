function Global.N_0x89e005b1662f6e48(p0, p1, p2)
	return _in(0x89E005B1662F6E48, p0, p1, p2, _r, _ri)
end
