function Global.N_0xf74e134f40192884(p0, p1)
	return _in(0xF74E134F40192884, p0, p1)
end
