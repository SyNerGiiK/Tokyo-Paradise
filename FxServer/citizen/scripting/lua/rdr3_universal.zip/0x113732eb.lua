function Global.N_0x951847cef3d829ff(p0, p1, p2)
	return _in(0x951847CEF3D829FF, p0, p1, p2)
end
