--- NativeDB Introduced: v1604
-- @param amount :
function Global.NetworkEarnFromAssassinateTargetKilled_2(amount)
	return _in(0x5E7AE8AABE8B7C0D, amount)
end
