function Global.RenderScriptCams(render, ease, easeTime, p3, p4, p5)
	return _in(0x33281167E4942E4F, render, ease, easeTime, p3, p4, p5)
end
