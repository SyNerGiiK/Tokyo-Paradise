function Global.IsEntityOnScreen(entity)
	return _in(0x613C15D5D8DB781F, entity, _r)
end
