function Global.N_0x63e7279d04160477(p0, p1)
	return _in(0x63E7279D04160477, p0, p1)
end
