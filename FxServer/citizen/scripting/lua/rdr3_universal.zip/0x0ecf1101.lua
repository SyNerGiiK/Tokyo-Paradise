function Global.N_0x4d107406667423be(p0, p1)
	return _in(0x4D107406667423BE, p0, p1)
end
