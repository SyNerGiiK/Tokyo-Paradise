function Global.N_0x50c14328119e1dd1(p0, p1)
	return _in(0x50C14328119E1DD1, p0, p1)
end
