function Global.UnlockMissionNewsStory(p0)
	return _in(0xB165AB7C248B2DC1, p0)
end
