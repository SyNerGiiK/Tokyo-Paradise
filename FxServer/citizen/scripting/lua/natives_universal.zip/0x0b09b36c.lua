--- HookOffset defines where the hook is attached. leave at 0 for default attachment.
-- When using the tow truck online, this is not used (set a breakpoint and never called during tow truck attachment)
function Global.AttachVehicleToTowTruck(towTruck, vehicle, rear, hookOffsetX, hookOffsetY, hookOffsetZ)
	return _in(0x29A16F8D621C4508, towTruck, vehicle, rear, hookOffsetX, hookOffsetY, hookOffsetZ)
end
