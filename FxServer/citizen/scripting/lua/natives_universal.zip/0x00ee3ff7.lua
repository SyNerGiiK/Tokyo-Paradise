function Global.DropAmbientProp(ped)
	return _in(0xAFF4710E2A0A6C12, ped)
end
