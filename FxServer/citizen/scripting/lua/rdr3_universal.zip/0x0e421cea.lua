function Global.N_0xedd964b7984ac291(p0, p1)
	return _in(0xEDD964B7984AC291, p0, p1, _r, _ri)
end
