function Global.N_0x451294e859ecc018(p0)
	return _in(0x451294E859ECC018, p0, _r, _ri)
end
