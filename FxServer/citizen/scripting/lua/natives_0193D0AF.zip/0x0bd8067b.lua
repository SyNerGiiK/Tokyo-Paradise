function Global.SetWeatherTypeNowPersist(weatherType)
	return _in(0xED712CA327900C8A, _ts(weatherType))
end
