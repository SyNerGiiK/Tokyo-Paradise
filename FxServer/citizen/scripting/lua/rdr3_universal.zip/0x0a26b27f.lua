function Global.N_0x390710d2dafa6bff(p0, p1)
	return _in(0x390710D2DAFA6BFF, p0, p1)
end
