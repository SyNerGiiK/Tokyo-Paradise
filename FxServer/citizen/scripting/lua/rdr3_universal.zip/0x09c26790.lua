function Global.GetHashOfThread(threadId)
	return _in(0x724CB89D35B283D0, threadId, _r, _ri)
end
