function Global.N_0x89783fddf079c88d(p0)
	return _in(0x89783FDDF079C88D, p0)
end
