function Global.N_0x3168ba5d6dece323()
	return _in(0x3168BA5D6DECE323)
end
