function Global.N_0x0f1cd8ca9e65d5f6(p0, p1)
	return _in(0x0F1CD8CA9E65D5F6, p0, p1)
end
