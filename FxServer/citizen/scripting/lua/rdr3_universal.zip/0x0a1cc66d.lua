function Global.N_0xc369e2234e34a0ca(p0, p1)
	return _in(0xC369E2234E34A0CA, p0, p1, _r, _ri)
end
