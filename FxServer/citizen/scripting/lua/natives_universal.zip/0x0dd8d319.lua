function Global.N_0xc91c6c55199308ca(cam, x, y, z)
	return _in(0xC91C6C55199308CA, cam, x, y, z)
end
