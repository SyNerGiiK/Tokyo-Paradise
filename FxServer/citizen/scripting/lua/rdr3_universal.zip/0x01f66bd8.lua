function Global.N_0x4bdebea5702b97a9(p0, p1, p2, p3, p4, p5)
	return _in(0x4BDEBEA5702B97A9, p0, p1, p2, p3, p4, p5)
end
