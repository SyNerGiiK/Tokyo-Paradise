function Global.N_0x4cc5f2fc1332577f(p0)
	return _in(0x4CC5F2FC1332577F, p0)
end
