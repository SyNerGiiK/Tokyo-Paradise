function Global.GetBlipInfoIdDisplay(blip)
	return _in(0x1E314167F701DC3B, blip, _r, _ri)
end
