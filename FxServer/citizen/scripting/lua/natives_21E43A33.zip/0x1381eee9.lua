function Global.NetworkIsPartyMember(p0)
	return _in(0x676ED266AADD31E0, p0, _r, _ri)
end
