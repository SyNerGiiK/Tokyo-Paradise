function Global.SetMapFullScreen(toggle)
	return _in(0x5354C5BA2EA868A4, toggle)
end
