function Global.N_0x78b3d19af6391a55(p0, p1)
	return _in(0x78B3D19AF6391A55, p0, p1)
end
