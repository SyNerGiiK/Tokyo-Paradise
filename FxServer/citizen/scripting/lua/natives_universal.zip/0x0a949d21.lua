--- Example here: www.gtaforums.com/topic/830463-help-with-turning-lights-green-and-causing-peds-to-crash-into-each-other/#entry1068211340
-- 0 = green
-- 1 = red
-- 2 = yellow
-- changing lights may not change the behavior of vehicles
function Global.SetEntityTrafficlightOverride(entity, state)
	return _in(0x57C5DB656185EAC4, entity, state)
end
