--- NativeDB Parameter 0: Hash model
function Global.IsThisModelAnAmphibiousQuadbike(model)
	return _in(0xA1A9FC1C76A6730D, model, _r)
end
