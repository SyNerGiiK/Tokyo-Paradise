function Global.N_0x098ab65b9ed9a9ec(heistName, cashEarned, xpEarned)
	return _in(0x098AB65B9ED9A9EC, _ts(heistName), cashEarned, xpEarned, _r)
end
