function Global.N_0x74f1d22efa71fab8()
	return _in(0x74F1D22EFA71FAB8, _r, _ri)
end
