function Global.N_0x57639fd876b68a91(p0)
	return _in(0x57639FD876B68A91, p0, _r, _ri)
end
