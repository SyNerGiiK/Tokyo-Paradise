function Global.GetThisScriptName()
	return _in(0x442E0A7EDE4A738A, _r, _s)
end
