function Global.N_0xb2092a1eaa7fd45f(player)
	return _in(0xB2092A1EAA7FD45F, player, _r)
end
