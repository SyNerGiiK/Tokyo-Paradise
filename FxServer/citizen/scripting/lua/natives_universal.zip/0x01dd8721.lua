--- Override the area where the camera will render the terrain.
-- p3, p4 and p5 are usually set to 0.0
function Global.SetFocusPosAndVel(x, y, z, offsetX, offsetY, offsetZ)
	return _in(0xBB7454BAFF08FE25, x, y, z, offsetX, offsetY, offsetZ)
end
