function Global.UgcIsLanguageSupported(p0)
	return _in(0xF53E48461B71EECB, p0, _r)
end
