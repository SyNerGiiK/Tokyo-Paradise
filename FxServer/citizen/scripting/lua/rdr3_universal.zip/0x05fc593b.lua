function Global.DoorSystemSetOpenRatio(p0, p1, p2)
	return _in(0xB6E6FBA95C7324AC, p0, p1, p2)
end
