function Global.DecorSetBool(entity, propertyName, value)
	return _in(0x6B1E8E2ED1335B71, entity, _ts(propertyName), value, _r)
end
