function Global.N_0xd04241bbf6d03a5e(p0)
	return _in(0xD04241BBF6D03A5E, p0, _r, _ri)
end
