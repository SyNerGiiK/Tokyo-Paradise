function Global.N_0xc6a7dc546e94fed5(p0, p1, p2, p3)
	return _in(0xC6A7DC546E94FED5, p0, p1, p2, p3, _r, _ri)
end
