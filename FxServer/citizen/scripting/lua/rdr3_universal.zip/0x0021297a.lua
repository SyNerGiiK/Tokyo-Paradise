function Global.N_0x16f798a05bb9e3b5(p0)
	return _in(0x16F798A05BB9E3B5, p0)
end
