function Global.N_0xc9b4b3a36f81fd75(p0)
	return _in(0xC9B4B3A36F81FD75, p0, _r, _ri)
end
