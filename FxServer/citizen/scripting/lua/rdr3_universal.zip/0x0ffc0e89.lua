function Global.RemoveVehiclesFromGeneratorsInArea(p0, p1, p2, p3, p4, p5)
	return _in(0xC619A44639BC0CB4, p0, p1, p2, p3, p4, p5)
end
