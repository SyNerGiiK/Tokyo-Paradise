function Global.N_0x6f2135b6129620c1(p0)
	return _in(0x6F2135B6129620C1, p0)
end
