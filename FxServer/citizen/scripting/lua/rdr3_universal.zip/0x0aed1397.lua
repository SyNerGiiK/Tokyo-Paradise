function Global.N_0xb096547d61868254(p0)
	return _in(0xB096547D61868254, p0, _r, _ri)
end
