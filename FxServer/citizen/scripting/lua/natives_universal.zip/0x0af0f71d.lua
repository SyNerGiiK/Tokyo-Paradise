function Global.ScaleformMovieMethodAddParamLatestBriefString(value)
	return _in(0xEC52C631A1831C03, value)
end
