function Global.N_0xf0fe8e790bfeb5bb(p0, p1)
	return _in(0xF0FE8E790BFEB5BB, p0, p1)
end
