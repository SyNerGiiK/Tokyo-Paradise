function Global.N_0x954451ea2d2120fb(p0, p1)
	return _in(0x954451EA2D2120FB, p0, p1)
end
