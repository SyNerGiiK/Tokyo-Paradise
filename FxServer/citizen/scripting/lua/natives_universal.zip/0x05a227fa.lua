function Global.NetworkGetRandomInt()
	return _in(0x599E4FA1F87EB5FF, _r, _ri)
end
