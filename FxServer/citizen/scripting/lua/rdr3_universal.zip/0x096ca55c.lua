function Global.N_0x2cd41ac000e6f611()
	return _in(0x2CD41AC000E6F611)
end
