function Global.PromptIsActive(prompt)
	return _in(0x546E342E01DE71CF, prompt, _r)
end
