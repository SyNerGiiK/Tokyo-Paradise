function Global.SetStateOfRayfireMapObject(object, state)
	return _in(0x5C29F698D404C5E1, object, state)
end
