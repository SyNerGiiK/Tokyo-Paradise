function Global.ResetAnimScene(animScene, p1)
	return _in(0x8FDF221F13537936, animScene, _ts(p1))
end
