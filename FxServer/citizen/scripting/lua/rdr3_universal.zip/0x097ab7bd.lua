function Global.SetPickupNotLootable(p0, p1)
	return _in(0x92E87F60F21A0C3A, p0, p1)
end
