--- Returns whether a [control](https://docs.fivem.net/game-references/controls/) is currently pressed.
-- @param inputGroup The control system instance to use. Usually set to 0.
-- @param control The control ID to check.
-- @return True if the control was pressed.
function Global.IsControlPressed(inputGroup, control)
	return _in(0xF3A21BCD95725A4A, inputGroup, control, _r)
end
