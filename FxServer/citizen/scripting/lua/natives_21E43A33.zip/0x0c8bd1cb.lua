function Global.CancelStuntJump()
	return _in(0xE6B7B0ACD4E4B75E)
end
