function Global.N_0xb65927f861e7ae39(p0, p1)
	return _in(0xB65927F861E7AE39, p0, p1, _r, _ri)
end
