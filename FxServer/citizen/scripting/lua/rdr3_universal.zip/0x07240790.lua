function Global.N_0xc70041408e16be2e(p0, p1, p2)
	return _in(0xC70041408E16BE2E, p0, p1, p2)
end
