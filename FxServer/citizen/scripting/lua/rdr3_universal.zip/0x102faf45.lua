function Global.GetEventExists(eventGroup, eventIndex)
	return _in(0xC9F59C0A710ECD34, eventGroup, eventIndex, _r)
end
