function Global.N_0x30146c25686b7836(p0, p1)
	return _in(0x30146C25686B7836, p0, p1, _r, _ri)
end
