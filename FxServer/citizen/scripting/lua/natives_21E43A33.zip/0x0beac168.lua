function Global.N_0x0c1f7d49c39d2289()
	return _in(0x0C1F7D49C39D2289, _r, _ri)
end
