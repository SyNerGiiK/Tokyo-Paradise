function Global.N_0xe72e5c1289bd1f40(p0)
	return _in(0xE72E5C1289BD1F40, p0, _r, _ri)
end
