function Global.N_0xfb680d403909dc70(p0, p1)
	return _in(0xFB680D403909DC70, p0, p1)
end
