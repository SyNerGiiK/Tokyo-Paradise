function Global.N_0xcd6f8a0335d821f9(p0)
	return _in(0xCD6F8A0335D821F9, p0)
end
