function Global.SetCamActive(cam, active)
	return _in(0x87295BCA613800C8, cam, active)
end
