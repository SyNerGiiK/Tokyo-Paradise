function Global.N_0x002babe0b7d53136(p0)
	return _in(0x002BABE0B7D53136, p0)
end
