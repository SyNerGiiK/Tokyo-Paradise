function Global.ClearPedAlternateWalkAnim(p0, p1)
	return _in(0x8844BBFCE30AA9E9, p0, p1)
end
