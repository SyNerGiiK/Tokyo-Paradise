function Global.N_0xddc64f5e31eedab6(p0)
	return _in(0xDDC64F5E31EEDAB6, p0, _r, _ri)
end
