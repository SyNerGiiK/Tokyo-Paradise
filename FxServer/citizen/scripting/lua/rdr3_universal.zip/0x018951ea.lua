function Global.N_0x0e3bdeed21beb945(p0, p1)
	return _in(0x0E3BDEED21BEB945, p0, p1)
end
