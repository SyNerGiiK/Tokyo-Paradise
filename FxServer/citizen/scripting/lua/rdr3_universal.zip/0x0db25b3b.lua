function Global.N_0xfb16f08f47b83b4c(p0)
	return _in(0xFB16F08F47B83B4C, p0)
end
