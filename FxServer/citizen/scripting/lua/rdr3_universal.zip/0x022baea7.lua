function Global.N_0xe824ce7d13fcb300(p0, p1)
	return _in(0xE824CE7D13FCB300, p0, p1)
end
