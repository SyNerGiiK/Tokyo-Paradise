function Global.N_0x61e111e323419e07(p0, p1, p2, p3)
	return _in(0x61E111E323419E07, p0, p1, p2, p3, _r, _ri)
end
