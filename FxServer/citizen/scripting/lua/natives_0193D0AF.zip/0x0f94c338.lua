function Global.NetworkAddFriend(p1)
	return _in(0x8E02D73914064223, _i, _ts(p1), _r)
end
