function Global.N_0x69e181772886f48b(p0)
	return _in(0x69E181772886F48B, p0, _r, _ri)
end
