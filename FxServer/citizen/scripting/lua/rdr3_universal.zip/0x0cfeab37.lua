function Global.N_0x482d17e45665da44(p0, p1)
	return _in(0x482D17E45665DA44, p0, p1)
end
