--- Climbs or vaults the nearest thing.
function Global.TaskClimb(ped, unused)
	return _in(0x89D9FCC2435112F1, ped, unused)
end
