function Global.SetDisableBreaking(rope, enabled)
	return _in(0x5CEC1A84620E7D5B, rope, enabled, _r, _ri)
end
