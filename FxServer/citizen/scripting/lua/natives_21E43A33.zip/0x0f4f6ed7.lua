function Global.RemovePedElegantly(ped)
	return _in(0xAC6D445B994DF95E, _ii(ped) --[[ may be optional ]])
end
