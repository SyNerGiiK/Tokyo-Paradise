function Global.SetVehicleProvidesCover(vehicle, toggle)
	return _in(0x5AFEEDD9BB2899D7, vehicle, toggle)
end
