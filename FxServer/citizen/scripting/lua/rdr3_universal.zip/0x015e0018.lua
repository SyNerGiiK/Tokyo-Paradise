function Global.N_0x76cbcd9eadc00955()
	return _in(0x76CBCD9EADC00955)
end
