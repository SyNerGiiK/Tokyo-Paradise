function Global.N_0xc8391c309684595a()
	return _in(0xC8391C309684595A)
end
