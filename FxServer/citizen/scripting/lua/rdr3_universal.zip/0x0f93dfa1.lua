function Global.N_0x9bbdcb8df789ebc1(p0, p1)
	return _in(0x9BBDCB8DF789EBC1, p0, p1)
end
