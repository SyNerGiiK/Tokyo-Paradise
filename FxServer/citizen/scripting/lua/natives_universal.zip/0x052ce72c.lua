function Global.N_0x40763ea7b9b783e7(p0, p1, p2)
	return _in(0x40763EA7B9B783E7, _ts(p0), p1, p2, _r, _ri)
end
