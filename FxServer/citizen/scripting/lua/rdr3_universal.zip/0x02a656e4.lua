function Global.N_0x2e036f0480b8bf02()
	return _in(0x2E036F0480B8BF02, _r, _ri)
end
