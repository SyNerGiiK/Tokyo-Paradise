function Global.N_0x629526aba383bcaa()
	return _in(0x629526ABA383BCAA)
end
