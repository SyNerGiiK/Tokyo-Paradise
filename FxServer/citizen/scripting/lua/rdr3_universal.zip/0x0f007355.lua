function Global.N_0xdd0b7c5ae58f721d(p0)
	return _in(0xDD0B7C5AE58F721D, p0, _r, _ri)
end
