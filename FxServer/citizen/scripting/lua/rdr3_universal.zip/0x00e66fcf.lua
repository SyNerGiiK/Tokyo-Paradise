function Global.Tan(p0)
	return _in(0x8C13DB96497B7ABF, p0, _r, _rf)
end
