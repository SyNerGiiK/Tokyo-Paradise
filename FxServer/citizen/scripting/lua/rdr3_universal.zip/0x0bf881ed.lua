function Global.N_0x002aac783ed323ed(p0, p1)
	return _in(0x002AAC783ED323ED, p0, p1)
end
