function Global.DatabindingAddDataBoolFromPath(p0, p1, p2)
	return _in(0x37BB86A751148A6A, p0, p1, p2, _r, _ri)
end
