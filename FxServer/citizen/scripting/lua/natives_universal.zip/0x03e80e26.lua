--- NativeDB Introduced: v323
function Global.N_0x50a8a36201dbf83e()
	return _in(0x50A8A36201DBF83E, _r, _ri)
end
