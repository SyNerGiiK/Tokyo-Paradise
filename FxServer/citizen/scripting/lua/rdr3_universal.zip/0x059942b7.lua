function Global.ItemDatabaseFilloutPriceModifierByKey(p0, p1)
	return _in(0x40C5D95818823C94, p0, p1, _r, _ri)
end
