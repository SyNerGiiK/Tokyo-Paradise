function Global.OverrideTrevorRage(p0)
	return _in(0x13AD665062541A7E, _ii(p0) --[[ may be optional ]])
end
