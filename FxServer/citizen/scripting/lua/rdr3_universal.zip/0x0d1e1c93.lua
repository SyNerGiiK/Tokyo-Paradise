function Global.N_0x6da15746d5cc1a92(p0, p1, p2, p3, p4, p5)
	return _in(0x6DA15746D5CC1A92, p0, p1, p2, p3, p4, p5)
end
