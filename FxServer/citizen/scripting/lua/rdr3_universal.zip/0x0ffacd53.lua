function Global.N_0x5594afe9de0c01b7(p0)
	return _in(0x5594AFE9DE0C01B7, p0, _r, _ri)
end
