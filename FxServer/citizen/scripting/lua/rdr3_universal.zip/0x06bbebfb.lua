function Global.DisablePlayerFiring(player, toggle)
	return _in(0x2970929FD5F9FC89, player, toggle)
end
