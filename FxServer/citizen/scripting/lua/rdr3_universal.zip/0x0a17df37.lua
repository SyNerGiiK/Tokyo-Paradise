function Global.GetEventData(eventGroup, eventIndex, argStructSize)
	return _in(0x57EC5FA4D4D6AFCA, eventGroup, eventIndex, _i, argStructSize, _r)
end
