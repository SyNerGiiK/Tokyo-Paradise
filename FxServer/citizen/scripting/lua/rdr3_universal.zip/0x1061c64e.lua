function Global.N_0x7efacc589b98c488(p0)
	return _in(0x7EFACC589B98C488, p0, _r, _ri)
end
