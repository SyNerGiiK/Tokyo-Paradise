function Global.DatafileGetNumNodes(p0)
	return _in(0xDF01B1F7A886B42D, p0, _r, _ri)
end
