function Global.IsControlPressed(padIndex, control)
	return _in(0xF3A21BCD95725A4A, padIndex, _ch(control), _r)
end
