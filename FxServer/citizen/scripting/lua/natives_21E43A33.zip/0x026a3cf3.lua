function Global.GetWaterHeight(x, y, z, height)
	return _in(0xF6829842C06AE524, x, y, z, _fi(height) --[[ may be optional ]], _r)
end
