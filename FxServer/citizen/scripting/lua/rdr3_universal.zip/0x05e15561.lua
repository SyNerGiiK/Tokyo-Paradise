function Global.N_0x12e09e278c6c29b7(p0)
	return _in(0x12E09E278C6C29B7, p0)
end
