function Global.N_0x138398153824e332()
	return _in(0x138398153824E332)
end
