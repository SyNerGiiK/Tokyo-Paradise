function Global.N_0x641351e9ad103890(p0, p1)
	return _in(0x641351E9AD103890, p0, p1)
end
