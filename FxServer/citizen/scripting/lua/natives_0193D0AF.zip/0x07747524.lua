function Global.N_0x9489659372a81585()
	return _in(0x9489659372A81585, _r, _ri)
end
