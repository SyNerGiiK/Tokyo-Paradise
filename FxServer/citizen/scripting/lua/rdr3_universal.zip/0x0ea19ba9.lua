function Global.IsAppRunning(p0)
	return _in(0x4E511D093A86AD49, p0, _r, _ri)
end
