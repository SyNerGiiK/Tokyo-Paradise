function Global.NetworkClockTimeOverride(hour, minute, second, p3, p4)
	return _in(0x669E223E64B1903C, hour, minute, second, p3, p4)
end
