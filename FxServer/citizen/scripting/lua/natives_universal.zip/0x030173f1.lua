--- Unloads the cutscene and doesn't do extra stuff that REMOVE_CUTSCENE does.
function Global.RemoveCutFile(cutsceneName)
	return _in(0xD00D76A7DFC9D852, _ts(cutsceneName))
end
