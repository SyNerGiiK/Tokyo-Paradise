function Global.TaskItemInteraction(p0, p1, p2, p3, p4, p5)
	return _in(0xAE72E7DF013AAA61, p0, p1, p2, p3, p4, p5)
end
