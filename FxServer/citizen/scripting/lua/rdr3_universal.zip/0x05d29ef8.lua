function Global.N_0xd4fa73fe628fec63(p0, p1)
	return _in(0xD4FA73FE628FEC63, p0, p1)
end
