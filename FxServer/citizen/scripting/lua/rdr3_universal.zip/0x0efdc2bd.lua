function Global.N_0xc64e597783be9a1d(entity, toggle)
	return _in(0xC64E597783BE9A1D, entity, toggle)
end
