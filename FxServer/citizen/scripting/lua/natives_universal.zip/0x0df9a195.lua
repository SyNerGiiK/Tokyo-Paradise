function Global.N_0xbcbfcd9d1dac19e2(cargobob, strength)
	return _in(0xBCBFCD9D1DAC19E2, cargobob, strength)
end
