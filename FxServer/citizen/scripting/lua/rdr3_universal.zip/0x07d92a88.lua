function Global.N_0x95b8e397b8f4360f(p0)
	return _in(0x95B8E397B8F4360F, p0, _r, _ri)
end
