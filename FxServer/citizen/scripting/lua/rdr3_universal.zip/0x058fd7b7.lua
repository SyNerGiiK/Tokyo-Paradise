function Global.ItemDatabaseLocalizationGetNumLabelTypes(p0)
	return _in(0xCEC6A41E8910486A, p0, _r, _ri)
end
