function Global.SetBlipFriendly(blip, toggle)
	return _in(0xB81656BC81FE24D1, blip, toggle)
end
