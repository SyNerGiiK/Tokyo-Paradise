--- Since latest patches has 18 parameters.
-- entity - entity to ignore
-- ```
-- ```
-- NativeDB Added Parameter 19: Any p18
-- NativeDB Added Parameter 20: Any p19
function Global.ShootSingleBulletBetweenCoordsWithExtraParams(x1, y1, z1, x2, y2, z2, damage, p7, weaponHash, ownerPed, isAudible, isInvisible, speed, entity, p14, p15, p16, p17)
	return _in(0xBFE5756E7407064A, x1, y1, z1, x2, y2, z2, damage, p7, _ch(weaponHash), ownerPed, isAudible, isInvisible, speed, entity, p14, p15, p16, p17)
end
