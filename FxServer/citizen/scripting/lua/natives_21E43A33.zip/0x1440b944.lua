function Global.SetAnimLooped(p0, p1, p2, p3)
	return _in(0x70033C3CC29A1FF4, p0, p1, p2, p3)
end
