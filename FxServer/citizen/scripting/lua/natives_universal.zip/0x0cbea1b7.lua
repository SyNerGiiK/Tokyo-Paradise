--- NativeDB Introduced: v1493
-- @param p0 :
-- @param p1 :
function Global.N_0x407dc5e97db1a4d3(p0, p1)
	return _in(0x407DC5E97DB1A4D3, p0, p1)
end
