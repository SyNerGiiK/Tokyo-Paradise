function Global.N_0x88ad6cc10d8d35b2(p0)
	return _in(0x88AD6CC10D8D35B2, p0, _r, _ri)
end
