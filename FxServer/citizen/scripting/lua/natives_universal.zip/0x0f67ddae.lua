function Global.IsCinematicCamShaking()
	return _in(0xBBC08F6B4CB8FF0A, _r)
end
