function Global.N_0xba2c49ea6a8d24ff(p0, p1, p2, p3, p4, p5, p6)
	return _in(0xBA2C49EA6A8D24FF, p0, p1, p2, p3, p4, p5, p6, _r, _ri)
end
