--- NativeDB Return Type: BOOL
function Global.IsMissionNewsStoryUnlocked(newsStory)
	return _in(0x66E49BF55B4B1874, newsStory, _r, _ri)
end
