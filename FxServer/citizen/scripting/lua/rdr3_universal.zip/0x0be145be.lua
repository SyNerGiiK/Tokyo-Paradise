function Global.FindAnimEventPhase(animDictionary, animName, p2)
	return _in(0x42718CC559BD7776, _ts(animDictionary), _ts(animName), _ts(p2), _i, _i, _r)
end
