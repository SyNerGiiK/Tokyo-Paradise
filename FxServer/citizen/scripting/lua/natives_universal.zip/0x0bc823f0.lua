--- NativeDB Introduced: v323
-- @param player :
function Global.N_0x0e3a041ed6ac2b45(player)
	return _in(0x0E3A041ED6AC2B45, player, _r, _rf)
end
