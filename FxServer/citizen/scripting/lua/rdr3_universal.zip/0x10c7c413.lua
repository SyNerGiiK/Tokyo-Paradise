function Global.N_0x0ccefc6c2c95da2a(p0, p1, p2, p3)
	return _in(0x0CCEFC6C2C95DA2A, p0, p1, p2, p3, _r, _ri)
end
