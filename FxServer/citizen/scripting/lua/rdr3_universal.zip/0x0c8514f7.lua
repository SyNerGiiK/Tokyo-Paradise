function Global.N_0xc8b29d18022ea2b7(p0)
	return _in(0xC8B29D18022EA2B7, p0, _r, _ri)
end
