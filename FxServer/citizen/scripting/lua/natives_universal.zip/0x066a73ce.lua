function Global.N_0x2b5e102e4a42f2bf()
	return _in(0x2B5E102E4A42F2BF, _r, _ri)
end
