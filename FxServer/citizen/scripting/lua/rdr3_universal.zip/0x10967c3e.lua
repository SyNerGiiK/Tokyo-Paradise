function Global.N_0xc08def658b2e51da(p0)
	return _in(0xC08DEF658B2E51DA, p0, _r, _ri)
end
