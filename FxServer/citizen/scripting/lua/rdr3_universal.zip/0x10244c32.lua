function Global.N_0x769bb7626b8cdb06(p0, p1, p2, p3, p4, p5, p6)
	return _in(0x769BB7626B8CDB06, p0, p1, p2, p3, p4, p5, p6, _r, _ri)
end
