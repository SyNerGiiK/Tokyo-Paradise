function Global.NetworkIsChattingInPlatformParty(p0)
	return _in(0x8DE9945BCC9AEC52, _ii(p0) --[[ may be optional ]], _r)
end
