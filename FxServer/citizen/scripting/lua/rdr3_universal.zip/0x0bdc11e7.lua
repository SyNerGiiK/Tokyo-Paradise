function Global.N_0x025a1b1fb03fbf61(p0, p1, p2, p3, p4)
	return _in(0x025A1B1FB03FBF61, p0, p1, p2, p3, p4, _r, _ri)
end
