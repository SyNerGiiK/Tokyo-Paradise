function Global.N_0x0eabf182fbb63d72(p0, p1, p2)
	return _in(0x0EABF182FBB63D72, p0, p1, p2)
end
