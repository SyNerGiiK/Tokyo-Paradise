--- This does not move an existing checkpoint... so wtf.
function Global.N_0xf51d36185993515d(checkpoint, posX, posY, posZ, unkX, unkY, unkZ)
	return _in(0xF51D36185993515D, checkpoint, posX, posY, posZ, unkX, unkY, unkZ)
end
