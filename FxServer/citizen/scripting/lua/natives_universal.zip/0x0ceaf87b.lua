--- Returns the room hash key from the current gameplay cam.
function Global.GetRoomKeyForGameViewport()
	return _in(0xA6575914D2A0B450, _r, _ri)
end
