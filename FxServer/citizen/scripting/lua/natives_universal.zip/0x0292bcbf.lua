function Global.N_0x0c82d21a77c22d49(p0, p1, p2, p3)
	return _in(0x0C82D21A77C22D49, p0, p1, p2, p3)
end
