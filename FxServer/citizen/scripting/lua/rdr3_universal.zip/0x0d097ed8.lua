function Global.N_0xf06c5b66de20b2b8(p0)
	return _in(0xF06C5B66DE20B2B8, p0)
end
