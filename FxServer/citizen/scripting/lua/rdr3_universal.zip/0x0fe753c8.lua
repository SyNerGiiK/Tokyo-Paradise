function Global.NetworkSetVehicleWheelsDestructible(p0, p1)
	return _in(0x0C8BC052AE87D744, p0, p1)
end
