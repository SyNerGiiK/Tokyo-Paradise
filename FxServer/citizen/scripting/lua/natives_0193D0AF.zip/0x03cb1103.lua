function Global.N_0xd1c55b110e4df534(p0)
	return _in(0xD1C55B110E4DF534, p0)
end
