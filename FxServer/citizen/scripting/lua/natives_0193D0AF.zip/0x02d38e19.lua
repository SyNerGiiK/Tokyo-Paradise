function Global.NetworkGetPresenceInviteHandle(p0, p1)
	return _in(0x38D5B0FEBB086F75, p0, _ii(p1) --[[ may be optional ]], _r)
end
