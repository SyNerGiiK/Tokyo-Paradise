function Global.DecorSetBool(entity, propertyName, value)
	return _in(0xFE26E4609B1C3772, entity, _ts(propertyName), value, _r)
end
