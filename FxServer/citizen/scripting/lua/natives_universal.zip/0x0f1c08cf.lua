function Global.CancelCurrentPoliceReport()
	return _in(0xB4F90FAF7670B16F)
end
