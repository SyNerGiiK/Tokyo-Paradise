function Global.IsCutsceneActive()
	return _in(0x991251AFC3981F84, _r)
end
