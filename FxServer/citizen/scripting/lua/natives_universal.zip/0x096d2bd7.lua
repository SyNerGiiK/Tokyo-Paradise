function Global.TaskVehicleAimAtPed(ped, target)
	return _in(0xE41885592B08B097, ped, target)
end
