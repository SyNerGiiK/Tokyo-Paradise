function Global.N_0xe887bd31d97793f6(p0)
	return _in(0xE887BD31D97793F6, p0, _r, _ri)
end
