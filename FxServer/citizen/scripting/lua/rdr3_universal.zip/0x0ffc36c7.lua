function Global.PokerFold(p0)
	return _in(0x3DFAB7D9BB45B5BE, p0, _r, _ri)
end
