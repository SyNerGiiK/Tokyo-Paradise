function Global.AddAttributePoints(p0, p1, p2)
	return _in(0x75415EE0CB583760, p0, p1, p2)
end
