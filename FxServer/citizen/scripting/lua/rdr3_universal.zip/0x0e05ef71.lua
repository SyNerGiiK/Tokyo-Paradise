function Global.DoesBlipExist(blip)
	return _in(0xCD82FA174080B3B1, blip, _r)
end
