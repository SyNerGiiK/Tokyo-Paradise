function Global.IsHelpMessageFadingOut()
	return _in(0x327EDEEEAC55C369, _r)
end
