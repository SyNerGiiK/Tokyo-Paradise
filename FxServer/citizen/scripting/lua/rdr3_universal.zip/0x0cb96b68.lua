function Global.N_0x1096603b519c905f(p0)
	return _in(0x1096603B519C905F, p0)
end
