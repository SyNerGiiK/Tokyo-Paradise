function Global.ReserveNetworkMissionObjects(amount)
	return _in(0x4E5C93BD0C32FBF8, amount)
end
