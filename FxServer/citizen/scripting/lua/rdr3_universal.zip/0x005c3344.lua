function Global.N_0x918990bd9ce08582(p0)
	return _in(0x918990BD9CE08582, p0, _r, _ri)
end
