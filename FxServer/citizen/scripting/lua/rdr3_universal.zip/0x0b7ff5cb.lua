function Global.N_0x31dc8d3f216d8509(p0)
	return _in(0x31DC8D3F216D8509, p0, _r, _ri)
end
