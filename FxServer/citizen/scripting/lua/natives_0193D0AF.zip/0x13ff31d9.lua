function Global.ClearFacialIdleAnimOverride(ped)
	return _in(0x726256CC1EEB182F, ped)
end
