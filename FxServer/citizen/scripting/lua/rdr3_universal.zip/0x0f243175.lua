function Global.N_0x72b2e00c9bac6789(p0, p1)
	return _in(0x72B2E00C9BAC6789, p0, p1, _r, _ri)
end
