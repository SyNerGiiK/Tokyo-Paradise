function Global.SetTextChatUnk(p0)
	return _in(0x1DB21A44B09E8BA3, p0)
end
