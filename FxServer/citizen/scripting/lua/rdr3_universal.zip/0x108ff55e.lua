function Global.N_0x981146e5c9ce9250(p0)
	return _in(0x981146E5C9CE9250, p0, _r, _ri)
end
