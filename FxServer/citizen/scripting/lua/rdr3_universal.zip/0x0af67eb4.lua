function Global.N_0x46cbcf0e98a4e156(p0, p1)
	return _in(0x46CBCF0E98A4E156, p0, p1)
end
