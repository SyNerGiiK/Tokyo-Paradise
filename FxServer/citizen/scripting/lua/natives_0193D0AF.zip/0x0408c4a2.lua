function Global.N_0x01a358d9128b7a86()
	return _in(0x01A358D9128B7A86, _r, _ri)
end
