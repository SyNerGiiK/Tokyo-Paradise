function Global.N_0xf6d9e1f3560cbf8e(p0, p1, p2, p3, p4)
	return _in(0xF6D9E1F3560CBF8E, p0, p1, p2, p3, p4, _r, _ri)
end
