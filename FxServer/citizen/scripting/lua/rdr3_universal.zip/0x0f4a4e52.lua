function Global.N_0x31f343383f19c987(p0, p1, p2)
	return _in(0x31F343383F19C987, p0, p1, p2)
end
