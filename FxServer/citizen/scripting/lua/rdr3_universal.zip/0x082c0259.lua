function Global.N_0x919af2d93e9aa89d(p0)
	return _in(0x919AF2D93E9AA89D, p0, _r, _ri)
end
