function Global.GetScreenActiveResolution()
	return _in(0x873C9F3104101DD3, _i, _i)
end
