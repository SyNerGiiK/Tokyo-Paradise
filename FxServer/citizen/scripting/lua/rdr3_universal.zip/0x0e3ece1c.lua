function Global.SetAttributeBonusRank(p0, p1, p2)
	return _in(0x920F9488BD115EFB, p0, p1, p2)
end
