function Global.N_0xfd3c31a2e45671e7(p0, p1)
	return _in(0xFD3C31A2E45671E7, p0, p1)
end
