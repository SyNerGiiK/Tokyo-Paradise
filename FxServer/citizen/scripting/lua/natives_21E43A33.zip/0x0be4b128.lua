function Global.GetLiveryName(vehicle, livery)
	return _in(0xB4C7A93837C91A1F, vehicle, _ts(livery), _r, _s)
end
