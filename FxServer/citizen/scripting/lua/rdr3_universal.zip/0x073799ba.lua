function Global.N_0xbc864a70ad55e0c1(p0, p1)
	return _in(0xBC864A70AD55E0C1, p0, p1, _r, _ri)
end
