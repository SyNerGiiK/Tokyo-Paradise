function Global.N_0x513f8aa5bf2f17cf(p0, p1, p2, p3, p4)
	return _in(0x513F8AA5BF2F17CF, p0, p1, p2, p3, p4, _r, _ri)
end
