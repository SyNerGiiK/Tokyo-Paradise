function Global.N_0xe023e8ac4ef7c117(p0, p1, p2, p3)
	return _in(0xE023E8AC4EF7C117, p0, p1, p2, p3, _r, _ri)
end
