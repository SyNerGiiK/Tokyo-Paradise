--- Sets the arm position of a bulldozer. Position must be a value between 0.0 and 1.0. Ignored when `p2` is set to false, instead incrementing arm position by 0.1 (or 10%).
-- @param vehicle :
-- @param position :
-- @param p2 :
function Global.SetVehicleBulldozerArmPosition(vehicle, position, p2)
	return _in(0xF8EBCCC96ADB9FB7, vehicle, position, p2)
end
