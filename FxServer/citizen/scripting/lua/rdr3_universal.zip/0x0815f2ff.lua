function Global.SetVehicleEngineCanDegrade(vehicle, toggle)
	return _in(0x48E4C137A71C2688, vehicle, toggle)
end
