function Global.N_0xb16fc7b364d86585()
	return _in(0xB16FC7B364D86585)
end
