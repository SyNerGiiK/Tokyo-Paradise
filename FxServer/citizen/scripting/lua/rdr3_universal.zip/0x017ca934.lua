function Global.N_0x2a6d1daab9ebb262(p0)
	return _in(0x2A6D1DAAB9EBB262, p0, _r, _ri)
end
