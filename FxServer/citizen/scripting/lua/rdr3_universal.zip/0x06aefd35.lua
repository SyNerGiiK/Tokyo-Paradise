function Global.N_0xa7dc9266ed6a4e51(p0)
	return _in(0xA7DC9266ED6A4E51, p0)
end
