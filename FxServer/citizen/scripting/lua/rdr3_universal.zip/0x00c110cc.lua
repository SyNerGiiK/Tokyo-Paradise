function Global.DatafileUnload(p0)
	return _in(0x129567F0C05F81B9, p0)
end
