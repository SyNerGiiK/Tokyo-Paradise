function Global.TaskPutPedDirectlyIntoMelee(ped, meleeTarget, p2, p3, p4, p5)
	return _in(0x1C6CD14A876FFE39, ped, meleeTarget, p2, p3, p4, p5)
end
