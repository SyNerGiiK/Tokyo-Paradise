function Global.IsAnyVehicleNearPoint(x, y, z, radius)
	return _in(0x5698BA4FD04D39C4, x, y, z, radius, _r)
end
