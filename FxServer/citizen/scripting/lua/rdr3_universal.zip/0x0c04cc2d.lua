function Global.N_0x0e17378642156790(p0, p1)
	return _in(0x0E17378642156790, p0, p1)
end
