function Global.N_0x92a1b55a59720395(p0, p1)
	return _in(0x92A1B55A59720395, p0, p1)
end
