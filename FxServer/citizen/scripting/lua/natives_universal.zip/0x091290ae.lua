function Global.NetworkGetTunableCloudCrc()
	return _in(0x10BD227A753B0D84, _r, _ri)
end
