function Global.IsPlayerTargettingEntity(p0, p1, p2)
	return _in(0x27F89FDC16688A7A, p0, p1, p2, _r)
end
