function Global.Asin(p0)
	return _in(0x6E3C15D296C15583, p0, _r, _rf)
end
