function Global.N_0xf216f74101968db0(p0)
	return _in(0xF216F74101968DB0, p0, _r, _ri)
end
