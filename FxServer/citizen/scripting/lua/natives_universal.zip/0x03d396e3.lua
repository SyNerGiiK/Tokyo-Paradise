function Global.SetTextDropShadow()
	return _in(0x1CA3E9EAC9D93E5E)
end
