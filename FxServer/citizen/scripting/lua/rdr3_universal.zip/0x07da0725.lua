function Global.N_0xc6258f41d86676e0(p0, p1, p2)
	return _in(0xC6258F41D86676E0, p0, p1, p2)
end
