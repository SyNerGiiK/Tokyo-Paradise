function Global.N_0x12e981d53b07bf48(p0)
	return _in(0x12E981D53B07BF48, p0, _r, _ri)
end
