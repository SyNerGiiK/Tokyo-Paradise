function Global.N_0xb72999d3120599df(p0, p1, p2)
	return _in(0xB72999D3120599DF, p0, p1, p2, _r, _ri)
end
