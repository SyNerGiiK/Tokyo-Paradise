function Global.DisableControlAction(inputGroup, control, disable)
	return _in(0xFE99B66D079CF6BC, inputGroup, control, disable)
end
