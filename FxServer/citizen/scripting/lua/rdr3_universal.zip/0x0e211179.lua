function Global.N_0x6abad7b0a854f8fb(p0)
	return _in(0x6ABAD7B0A854F8FB, p0, _r, _ri)
end
