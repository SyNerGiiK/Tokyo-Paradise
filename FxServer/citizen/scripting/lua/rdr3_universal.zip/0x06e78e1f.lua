function Global.N_0x7c9e45a4ced2e8da(p0, p1)
	return _in(0x7C9E45A4CED2E8DA, p0, p1)
end
