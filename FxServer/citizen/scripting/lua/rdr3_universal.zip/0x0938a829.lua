function Global.SetWeatherTypeTransition(p0, p1, p2, p3)
	return _in(0xFA3E3CA8A1DE6D5D, p0, p1, p2, p3)
end
