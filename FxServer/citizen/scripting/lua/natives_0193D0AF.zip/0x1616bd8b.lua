function Global.N_0x5db8010ee71fdef2(vehicle)
	return _in(0x5DB8010EE71FDEF2, vehicle, _r)
end
