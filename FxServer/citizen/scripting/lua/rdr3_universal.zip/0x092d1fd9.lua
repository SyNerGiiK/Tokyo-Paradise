function Global.NetworkGetClockTimeOverride()
	return _in(0x11A7ADCD629E170F, _i, _i, _i, _r)
end
