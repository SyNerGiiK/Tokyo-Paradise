--- NativeDB Return Type: void
function Global.SetDisableBreaking(object, toggle)
	return _in(0x5CEC1A84620E7D5B, object, toggle, _r, _ri)
end
