function Global.N_0x8e462db1eaa9c47c(p0)
	return _in(0x8E462DB1EAA9C47C, p0, _r, _ri)
end
