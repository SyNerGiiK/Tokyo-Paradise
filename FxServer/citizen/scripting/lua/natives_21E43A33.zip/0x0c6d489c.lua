function Global.N_0x129466ed55140f8d(p0, p1)
	return _in(0x129466ED55140F8D, p0, p1)
end
