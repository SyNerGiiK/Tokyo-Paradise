function Global.N_0x5b4bbe80ad5972dc(p0, p1, p2, p3, p4, p5, p6, p7)
	return _in(0x5B4BBE80AD5972DC, p0, p1, p2, p3, p4, p5, p6, p7, _r, _ri)
end
