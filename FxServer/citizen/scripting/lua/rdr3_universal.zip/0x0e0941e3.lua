function Global.N_0x6c4dbf553885f9eb(p0, p1, p2)
	return _in(0x6C4DBF553885F9EB, p0, p1, p2, _r, _ri)
end
