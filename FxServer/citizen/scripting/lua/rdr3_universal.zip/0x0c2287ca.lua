function Global.N_0x77ba37622e22023b(p0, p1, p2, p3, p4)
	return _in(0x77BA37622E22023B, p0, p1, p2, p3, p4, _r, _ri)
end
