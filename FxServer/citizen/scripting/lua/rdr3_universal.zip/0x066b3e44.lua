function Global.ObjectValueGetArray(key)
	return _in(0x1B5447CF18544B18, _i, _ts(key), _r, _ri)
end
